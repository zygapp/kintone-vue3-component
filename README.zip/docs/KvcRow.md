# KvcRow

## 概要
フォーム内の一行分をレイアウトするためのユーティリティラッパーです。

## 使用例

```vue
<template>
  <KvcRow>
    <KvcField>
      <KvcTextInput v-model="text" />
    </KvcField>
  </KvcRow>
</template>
```

## Props
なし（ラッパーのみ）


---

[◀ 戻る](../README.md)