<template>
  <div class="kvc-row">
    <slot></slot>
  </div>
</template>