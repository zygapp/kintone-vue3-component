declare module '@zygapp/kintone-vue3-component';
