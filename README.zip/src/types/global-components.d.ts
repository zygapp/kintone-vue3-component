import { DefineComponent } from 'vue'

export interface KintoneVueGlobalComponents {
  KvcButton: DefineComponent<{ label?: string }>
  KvcCheckbox: DefineComponent<{ modelValue?: boolean }>
  KvcDatePicker: DefineComponent<{ modelValue?: string }>
  KvcDateTimePicker: DefineComponent<{ modelValue?: string }>
  KvcDropdown: DefineComponent<{ options: any[]; modelValue?: any }>
  KvcField: DefineComponent
  KvcFileSelect: DefineComponent
  KvcRadio: DefineComponent<{ options: any[]; modelValue?: any }>
  KvcRow: DefineComponent
  KvcTable: DefineComponent<{ items: any[] }>
  KvcTextInput: DefineComponent<{ modelValue?: string }>
  KvcTextarea: DefineComponent<{ modelValue?: string }>
  KvcTimePicker: DefineComponent<{ modelValue?: string }>
  KvcWrap: DefineComponent
}

declare module 'vue' {
  export interface GlobalComponents extends KintoneVueGlobalComponents {}
}
